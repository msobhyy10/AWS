from setuptools import setup

setup(name='udacity_aws_probability_dist',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['udacity_aws_probability_dist'],
      author = 'Muhamed Sobhy',
      author_email = 'mosobhyy74@gmail.com',
      zip_safe=False)
